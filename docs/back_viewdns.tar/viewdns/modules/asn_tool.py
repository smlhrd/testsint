#/usr/bin/python
# -*- coding: utf-8 -*-

from shell import shell
from bs4 import BeautifulSoup
import clean_html

import warnings
warnings.filterwarnings("ignore")

def do_call(param):
    url = "https://viewdns.info/asnlookup/?asn=%s" % param
    #erg = shell("./reverse_test.sh %s" % url)
    
    ######## Test clean html start ################
    
    clean_html.copy_clean()
    
    ######## Test clean html Ende ################
    
    
    soup = BeautifulSoup(open('erg_clean.html'), 'html.parser')
    fh_out = open("asn.txt","w")
    var = soup.text.encode("ascii", "ignore")
    fh_out.write(var[4432:-1000])
    
    """dom_table = soup.find_all('table')
    dom_table = dom_table[3]

    with open('reverse_whois.txt', 'w') as r:

        for rows in dom_table.find_all('tr'):
            for cells in rows.find_all('td'):
                print cells
                #r.write(cells.text())#.ljust(35))
            r.write('\n')
    fh_out = open('reverse_whois.txt', 'r')
    for line in fh_out.readlines():
        print line.rstrip()"""