#!/bin/bash

DOMAIN=$1
IPADDR=$2

rm -f erg_dom.txt
rm -f erg_ip.txt
rm -f cleared_erg.txt

whois $DOMAIN > erg_dom.txt
whois $IPADDR > erg_ip.txt
